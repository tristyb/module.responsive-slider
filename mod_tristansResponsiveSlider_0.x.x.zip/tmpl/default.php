<div class="flexslider">
	<ul class="slides">
		<?php
			echo $slides;
		?>
	</ul>
</div>
