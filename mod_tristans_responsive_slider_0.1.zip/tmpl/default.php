<?php

/**
 * TRISTAN'S RESPONSIVE SLIDER
 * @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

?>

<div class="flexslider">
	<ul class="slides">
		<?php
			echo $slides;
		?>
	</ul>
</div>
